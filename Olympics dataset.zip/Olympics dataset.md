```python
import pandas as pd      # importing libraries in python
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
data = pd.read_csv("C:/Users/ASUS/OneDrive/Desktop/EDA/dataset_olympics.csv")     # to load data
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>Height</th>
      <th>Weight</th>
      <th>Team</th>
      <th>NOC</th>
      <th>Games</th>
      <th>Year</th>
      <th>Season</th>
      <th>City</th>
      <th>Sport</th>
      <th>Event</th>
      <th>Medal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>A Dijiang</td>
      <td>M</td>
      <td>24.0</td>
      <td>180.0</td>
      <td>80.0</td>
      <td>China</td>
      <td>CHN</td>
      <td>1992 Summer</td>
      <td>1992</td>
      <td>Summer</td>
      <td>Barcelona</td>
      <td>Basketball</td>
      <td>Basketball Men's Basketball</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>A Lamusi</td>
      <td>M</td>
      <td>23.0</td>
      <td>170.0</td>
      <td>60.0</td>
      <td>China</td>
      <td>CHN</td>
      <td>2012 Summer</td>
      <td>2012</td>
      <td>Summer</td>
      <td>London</td>
      <td>Judo</td>
      <td>Judo Men's Extra-Lightweight</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Gunnar Nielsen Aaby</td>
      <td>M</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Denmark</td>
      <td>DEN</td>
      <td>1920 Summer</td>
      <td>1920</td>
      <td>Summer</td>
      <td>Antwerpen</td>
      <td>Football</td>
      <td>Football Men's Football</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Edgar Lindenau Aabye</td>
      <td>M</td>
      <td>34.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Denmark/Sweden</td>
      <td>DEN</td>
      <td>1900 Summer</td>
      <td>1900</td>
      <td>Summer</td>
      <td>Paris</td>
      <td>Tug-Of-War</td>
      <td>Tug-Of-War Men's Tug-Of-War</td>
      <td>Gold</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Christine Jacoba Aaftink</td>
      <td>F</td>
      <td>21.0</td>
      <td>185.0</td>
      <td>82.0</td>
      <td>Netherlands</td>
      <td>NED</td>
      <td>1988 Winter</td>
      <td>1988</td>
      <td>Winter</td>
      <td>Calgary</td>
      <td>Speed Skating</td>
      <td>Speed Skating Women's 500 metres</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>69995</th>
      <td>35656</td>
      <td>Stuart Fitzsimmons</td>
      <td>M</td>
      <td>19.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Great Britain</td>
      <td>GBR</td>
      <td>1976 Winter</td>
      <td>1976</td>
      <td>Winter</td>
      <td>Innsbruck</td>
      <td>Alpine Skiing</td>
      <td>Alpine Skiing Men's Giant Slalom</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>69996</th>
      <td>35656</td>
      <td>Stuart Fitzsimmons</td>
      <td>M</td>
      <td>19.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Great Britain</td>
      <td>GBR</td>
      <td>1976 Winter</td>
      <td>1976</td>
      <td>Winter</td>
      <td>Innsbruck</td>
      <td>Alpine Skiing</td>
      <td>Alpine Skiing Men's Slalom</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>69997</th>
      <td>35657</td>
      <td>David Thomas "Dave" Fitzsimons</td>
      <td>M</td>
      <td>26.0</td>
      <td>170.0</td>
      <td>65.0</td>
      <td>Australia</td>
      <td>AUS</td>
      <td>1976 Summer</td>
      <td>1976</td>
      <td>Summer</td>
      <td>Montreal</td>
      <td>Athletics</td>
      <td>Athletics Men's 10,000 metres</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>69998</th>
      <td>35657</td>
      <td>David Thomas "Dave" Fitzsimons</td>
      <td>M</td>
      <td>30.0</td>
      <td>170.0</td>
      <td>65.0</td>
      <td>Australia</td>
      <td>AUS</td>
      <td>1980 Summer</td>
      <td>1980</td>
      <td>Summer</td>
      <td>Moskva</td>
      <td>Athletics</td>
      <td>Athletics Men's 5,000 metres</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>69999</th>
      <td>35658</td>
      <td>Marek Fiurek</td>
      <td>M</td>
      <td>23.0</td>
      <td>180.0</td>
      <td>68.0</td>
      <td>Czech Republic</td>
      <td>CZE</td>
      <td>1998 Winter</td>
      <td>1998</td>
      <td>Winter</td>
      <td>Nagano</td>
      <td>Nordic Combined</td>
      <td>Nordic Combined Men's Team</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>70000 rows × 15 columns</p>
</div>




```python
data.head()    # to get few information
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>Height</th>
      <th>Weight</th>
      <th>Team</th>
      <th>NOC</th>
      <th>Games</th>
      <th>Year</th>
      <th>Season</th>
      <th>City</th>
      <th>Sport</th>
      <th>Event</th>
      <th>Medal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>A Dijiang</td>
      <td>M</td>
      <td>24.0</td>
      <td>180.0</td>
      <td>80.0</td>
      <td>China</td>
      <td>CHN</td>
      <td>1992 Summer</td>
      <td>1992</td>
      <td>Summer</td>
      <td>Barcelona</td>
      <td>Basketball</td>
      <td>Basketball Men's Basketball</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>A Lamusi</td>
      <td>M</td>
      <td>23.0</td>
      <td>170.0</td>
      <td>60.0</td>
      <td>China</td>
      <td>CHN</td>
      <td>2012 Summer</td>
      <td>2012</td>
      <td>Summer</td>
      <td>London</td>
      <td>Judo</td>
      <td>Judo Men's Extra-Lightweight</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Gunnar Nielsen Aaby</td>
      <td>M</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Denmark</td>
      <td>DEN</td>
      <td>1920 Summer</td>
      <td>1920</td>
      <td>Summer</td>
      <td>Antwerpen</td>
      <td>Football</td>
      <td>Football Men's Football</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Edgar Lindenau Aabye</td>
      <td>M</td>
      <td>34.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Denmark/Sweden</td>
      <td>DEN</td>
      <td>1900 Summer</td>
      <td>1900</td>
      <td>Summer</td>
      <td>Paris</td>
      <td>Tug-Of-War</td>
      <td>Tug-Of-War Men's Tug-Of-War</td>
      <td>Gold</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Christine Jacoba Aaftink</td>
      <td>F</td>
      <td>21.0</td>
      <td>185.0</td>
      <td>82.0</td>
      <td>Netherlands</td>
      <td>NED</td>
      <td>1988 Winter</td>
      <td>1988</td>
      <td>Winter</td>
      <td>Calgary</td>
      <td>Speed Skating</td>
      <td>Speed Skating Women's 500 metres</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.info()     # to get the basic details of data set
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 70000 entries, 0 to 69999
    Data columns (total 15 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   ID      70000 non-null  int64  
     1   Name    70000 non-null  object 
     2   Sex     70000 non-null  object 
     3   Age     67268 non-null  float64
     4   Height  53746 non-null  float64
     5   Weight  52899 non-null  float64
     6   Team    70000 non-null  object 
     7   NOC     70000 non-null  object 
     8   Games   70000 non-null  object 
     9   Year    70000 non-null  int64  
     10  Season  70000 non-null  object 
     11  City    70000 non-null  object 
     12  Sport   70000 non-null  object 
     13  Event   70000 non-null  object 
     14  Medal   9690 non-null   object 
    dtypes: float64(3), int64(2), object(10)
    memory usage: 8.0+ MB
    


```python
data.describe()  # to attain statistical information
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Age</th>
      <th>Height</th>
      <th>Weight</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>70000.000000</td>
      <td>67268.000000</td>
      <td>53746.000000</td>
      <td>52899.000000</td>
      <td>70000.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>18081.846986</td>
      <td>25.644645</td>
      <td>175.505303</td>
      <td>70.900216</td>
      <td>1977.766457</td>
    </tr>
    <tr>
      <th>std</th>
      <td>10235.613253</td>
      <td>6.485239</td>
      <td>10.384203</td>
      <td>14.217489</td>
      <td>30.103306</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>11.000000</td>
      <td>127.000000</td>
      <td>25.000000</td>
      <td>1896.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>9325.750000</td>
      <td>21.000000</td>
      <td>168.000000</td>
      <td>61.000000</td>
      <td>1960.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>18032.000000</td>
      <td>25.000000</td>
      <td>175.000000</td>
      <td>70.000000</td>
      <td>1984.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>26978.000000</td>
      <td>28.000000</td>
      <td>183.000000</td>
      <td>79.000000</td>
      <td>2002.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>35658.000000</td>
      <td>88.000000</td>
      <td>223.000000</td>
      <td>214.000000</td>
      <td>2016.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.describe(include=["object"])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Sex</th>
      <th>Team</th>
      <th>NOC</th>
      <th>Games</th>
      <th>Season</th>
      <th>City</th>
      <th>Sport</th>
      <th>Event</th>
      <th>Medal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>70000</td>
      <td>70000</td>
      <td>70000</td>
      <td>70000</td>
      <td>70000</td>
      <td>70000</td>
      <td>70000</td>
      <td>70000</td>
      <td>70000</td>
      <td>9690</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>35556</td>
      <td>2</td>
      <td>827</td>
      <td>226</td>
      <td>51</td>
      <td>2</td>
      <td>42</td>
      <td>65</td>
      <td>744</td>
      <td>3</td>
    </tr>
    <tr>
      <th>top</th>
      <td>Oksana Aleksandrovna Chusovitina</td>
      <td>M</td>
      <td>United States</td>
      <td>USA</td>
      <td>2016 Summer</td>
      <td>Summer</td>
      <td>London</td>
      <td>Athletics</td>
      <td>Football Men's Football</td>
      <td>Gold</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>29</td>
      <td>51877</td>
      <td>4979</td>
      <td>5216</td>
      <td>3675</td>
      <td>58467</td>
      <td>6034</td>
      <td>10629</td>
      <td>1738</td>
      <td>3292</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.isna().sum()    # to get missing values
```




    ID            0
    Name          0
    Sex           0
    Age        2732
    Height    16254
    Weight    17101
    Team          0
    NOC           0
    Games         0
    Year          0
    Season        0
    City          0
    Sport         0
    Event         0
    Medal     60310
    dtype: int64




```python
data.duplicated().sum()    # to get the duplicate values
```




    np.int64(383)




```python
data.drop_duplicates(inplace=True)
```


```python
data.duplicated().sum()
```




    np.int64(0)




```python
# visualising
sns.countplot(data=data, x="Sex",hue="Sex")
plt.title("Distribution by Gender")
plt.show()
```


    
![png](output_10_0.png)
    



```python
sns.histplot(data=data, x="Age",color="red",bins=20,kde=True)
plt.title("Age Distribution")
plt.show()
```


    
![png](output_11_0.png)
    



```python
sns.histplot(data=data,x="Height",color="Orange",bins=20,kde=True)
plt.title("Height Distribution")
plt.show()
```


    
![png](output_12_0.png)
    



```python
sns.histplot(data=data,x="Weight",color="green",bins=20,kde=True)
plt.title("Weight Distribution")
plt.show()
```


    
![png](output_13_0.png)
    



```python
sns.countplot(data=data,x="Medal",hue="Medal")
plt.title("Medal Distribution")
plt.show()
```


    
![png](output_14_0.png)
    



```python
sns.countplot(data=data,x="Year",hue="Medal")
plt.title("Medal Distribution Over the Years")
plt.xticks(rotation=60)
plt.show()
```


    
![png](output_15_0.png)
    



```python
year_avg_age=data.groupby("Year")["Age"].mean()
print(year_avg_age)
```

    Year
    1896    23.029412
    1900    29.119883
    1904    27.063241
    1906    26.989474
    1908    27.000000
    1912    27.965552
    1920    29.241135
    1924    28.252267
    1928    27.973564
    1932    29.606987
    1936    27.245665
    1948    28.363170
    1952    26.273684
    1956    26.316156
    1960    25.136156
    1964    24.852107
    1968    24.316722
    1972    24.126448
    1976    23.656820
    1980    23.312364
    1984    24.060328
    1988    24.257374
    1992    24.637827
    1994    24.487516
    1996    25.338210
    1998    25.143860
    2000    25.435177
    2002    26.029095
    2004    25.780111
    2006    26.091716
    2008    25.685148
    2010    26.150776
    2012    25.993485
    2014    26.082814
    2016    26.259592
    Name: Age, dtype: float64
    


```python
sport_median_height=data.groupby("Sport")["Height"].median()
print(sport_median_height)
```

    Sport
    Alpine Skiing       173.0
    Alpinism              NaN
    Archery             172.0
    Art Competitions    183.0
    Athletics           176.0
                        ...  
    Tug-Of-War          182.0
    Volleyball          187.5
    Water Polo          185.0
    Weightlifting       168.0
    Wrestling           172.0
    Name: Height, Length: 65, dtype: float64
    


```python
sport_median_height=data.groupby("Sport")["Height"].median()
print(sport_median_height.max())
```

    190.0
    


```python
sport_median_height[sport_median_height==190.0]
```




    Sport
    Basketball    190.0
    Name: Height, dtype: float64




```python
sport_median_height=data.groupby("Sport")["Height"].median()
print(sport_median_height.min())
```

    164.0
    


```python
sport_median_height[sport_median_height==164.0]
```




    Sport
    Gymnastics    164.0
    Name: Height, dtype: float64




```python
country_gender_count=data.groupby(["NOC","Sex"])["ID"].count()
print(country_gender_count)
```

    NOC  Sex
    AFG  M       38
    AHO  F        6
         M       27
    ALB  F        4
         M        7
               ... 
    YUG  M      455
    ZAM  F        3
         M       40
    ZIM  F       41
         M       47
    Name: ID, Length: 432, dtype: int64
    


```python
country_gold_medals=data[data["Medal"]=="Gold"].groupby("NOC")["Medal"].count()
print(country_gold_medals)
```

    NOC
    ALG      1
    ANZ      7
    ARG     25
    ARM      1
    AUS     98
          ... 
    URU     13
    USA    747
    UZB      4
    YUG     31
    ZIM      7
    Name: Medal, Length: 84, dtype: int64
    


```python
country_gold_medals=data[data["Medal"]=="Gold"].groupby("NOC")["Medal"].count()
print(country_gold_medals.max())
```

    747
    


```python
country_gold_medals[country_gold_medals==747]
```




    NOC
    USA    747
    Name: Medal, dtype: int64




```python
country_gold_medals=data[data["Medal"]=="Gold"].groupby("NOC")["Medal"].count()
print(country_gold_medals.min())
```

    1
    


```python
country_gold_medals[country_gold_medals==1]
```




    NOC
    ALG    1
    ARM    1
    AZE    1
    CIV    1
    COL    1
    DOM    1
    GEO    1
    IOA    1
    IRI    1
    JOR    1
    LUX    1
    MGL    1
    NEP    1
    POR    1
    THA    1
    UAE    1
    UGA    1
    Name: Medal, dtype: int64




```python
sport_gender_avg_weight=data.groupby(["Sport","Sex"])["Weight"].mean()
print(sport_gender_avg_weight)
```

    Sport          Sex
    Alpine Skiing  F      62.154589
                   M      77.725309
    Alpinism       F            NaN
                   M            NaN
    Archery        F      61.023256
                            ...    
    Water Polo     M      87.584973
    Weightlifting  F      66.189474
                   M      79.927852
    Wrestling      F      58.169014
                   M      77.256240
    Name: Weight, Length: 114, dtype: float64
    


```python
sport_gender_avg_weight=data.groupby(["Sport","Sex"])["Weight"].mean()
print(sport_gender_avg_weight["Wrestling"])
```

    Sex
    F    58.169014
    M    77.256240
    Name: Weight, dtype: float64
    


```python
sport_gender_avg_weight=data.groupby(["Sport","Sex"])["Weight"].mean()
print(sport_gender_avg_weight["Wrestling"]["F"])
```

    58.16901408450704
    


```python
sport_event_count=data.groupby("Sport")["Event"].nunique().sort_values(ascending=False)
sport_event_count.head(15).plot(kind="bar",figsize=(10,5),rot=45)
plt.title("Number of Unique Events per sport")
plt.xlabel("Sport")
plt.ylabel("Number of Unique Events")
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_31_0.png)
    



```python
year_participant_count=data.groupby("Year")["ID"].nunique()
year_participant_count.plot(kind="line",marker="o")
plt.title("Number of Participants Over the Years")
plt.xlabel("Year")
plt.ylabel("Number of Participants")
plt.show()
```


    
![png](output_32_0.png)
    



```python
country_avg_age=data.groupby("NOC")["Age"].mean().sort_values(ascending=False)
country_avg_age.head(10).plot(kind="bar")
plt.title("Top 10 countries with Highest Average Age of Participants")
plt.xlabel("Country")
plt.ylabel("Average Age")
plt.xticks(rotation=45)
plt.show()
```


    
![png](output_33_0.png)
    



```python
country_avg_age=data.groupby("NOC")["Age"].mean().sort_values(ascending=False)
country_avg_age.tail(10).plot(kind="bar")
plt.title("Top 10 countries with Lowest Average Age of Participants")
plt.xlabel("Country")
plt.ylabel("Average Age")
plt.xticks(rotation=45)
plt.show()
```


    
![png](output_34_0.png)
    



```python
sns.boxplot(data=data,x="Season",y="Age",hue="Season")
plt.title("Distribution of Ages by Season")
plt.xlabel("Season")
plt.ylabel("Age")
plt.show()
```


    
![png](output_35_0.png)
    



```python
sns.violinplot(data=data,x="Medal",y="Height",hue="Medal",palette="Set2",legend=False)
plt.title("Distribution of Heights by Medal")
plt.xlabel("Medal")
plt.ylabel("Height")
plt.show()
```


    
![png](output_36_0.png)
    



```python
most_medals_country=data["NOC"].value_counts().idxmax()
print("Most Medal_Winning Country: ", most_medals_country)
```

    Most Medal_Winning Country:  USA
    


```python
tallest_athlete=data[data["Height"]==data["Height"].max()]
print("Tallest Athlete:")
print(tallest_athlete[["ID","Name","Height","Sport"]])

```

    Tallest Athlete:
              ID                  Name  Height       Sport
    32376  16639  Tommy Loren Burleson   223.0  Basketball
    


```python
heaviest_athlete=data[data["Weight"]==data["Weight"].max()]
print("Heaviest athlete: ")
print(heaviest_athlete[["ID","Name","Weight","Sport"]])
    
```

    Heaviest athlete: 
              ID               Name  Weight Sport
    23155  12177  Ricardo Blas, Jr.   214.0  Judo
    23156  12177  Ricardo Blas, Jr.   214.0  Judo
    


```python
heaviest_athlete=data[data["Weight"]==data["Weight"].min()]
print("Heaviest athlete: ")
print(heaviest_athlete[["ID","Name","Weight","Sport"]])
```

    Heaviest athlete: 
              ID            Name  Weight       Sport
    40849  21049  Choi Myong-Hui    25.0  Gymnastics
    40850  21049  Choi Myong-Hui    25.0  Gymnastics
    40851  21049  Choi Myong-Hui    25.0  Gymnastics
    40852  21049  Choi Myong-Hui    25.0  Gymnastics
    40853  21049  Choi Myong-Hui    25.0  Gymnastics
    40854  21049  Choi Myong-Hui    25.0  Gymnastics
    


```python
sns.scatterplot(data=data,x="Height",y="Weight",hue="Medal",palette="Set1")
plt.title("Athlete Height vs Weight by Medal Status")
plt.xlabel("Height")
plt.ylabel("Weight")
plt.legend(title="Medal")
plt.show()
```


    
![png](output_41_0.png)
    



```python
medals_by_country_year=data.pivot_table(index="NOC",columns="Year",values="Medal",aggfunc="count")
sns.heatmap(medals_by_country_year,cmap="YlGnBu",linewidths=0.5)
plt.title("Medal Counts by Country and Year")
plt.xlabel("Year")
plt.ylabel("Country")
plt.xticks(rotation=45)
plt.show()



```


    
![png](output_42_0.png)
    



```python

```
